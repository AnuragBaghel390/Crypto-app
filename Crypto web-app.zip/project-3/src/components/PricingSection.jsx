import { CustomCard } from '../chakra/CustomCard'
import { Button, Flex, HStack, Icon, Image, Stack, Tab, TabList, TabPanels, TabPanel, Tabs, Text } from '@chakra-ui/react'
import { MdOutlineArrowOutward } from "react-icons/md";
import { FaCircleMinus, FaCirclePlus } from "react-icons/fa6";



const PricingSection = () => {

    const timesamps = ["7:15PM", "7:55PM","8:55PM","9:55PM","10:55PM",];

  return (
    <CustomCard>

        <Flex justify="space-between" align="start">
        <Stack>
            <HStack color="black.80">
                <Text fontSize="sm" >Wallet Balances </Text>
            </HStack>
            <HStack spacing={2} align={{base:"flex-start", sm:"center,"}} flexDir={{base: "column", sm:"row",}}>
            <HStack fontWeight="medium" color="green.500" >
            <Text textStyle="h2"  fontWeight="medium">22.39401000</Text>
            <Icon as={MdOutlineArrowOutward} />
            <Text fontSize="sm"  fontWeight="medium">22%</Text> 
            </HStack>
            <HStack>
            </HStack >
            </HStack>
        </Stack>

        <HStack>
            <Button leftIcon={<Icon as={FaCirclePlus}/>} >Buy</Button>
            <Button leftIcon={<Icon as={FaCircleMinus }/>}>Sell</Button>
        </HStack>


        </Flex>
        <Tabs variant='soft-rounded' colorScheme='green'>
            <Flex justify="end" >
            <TabList bg="black.5" p="3px">
                {
                    ["1H","1D","1W","1M"].map((tab) =>(
                        <Tab _selected={{ bg:"white" }} key={tab} fontSize="sm" p="6px" borderRadius="4">
                            {tab}
                        </Tab>
                    ))
                }
            </TabList>
            </Flex>
            <TabPanels >
                <TabPanel >
                    <Image w="100%" src="/graph.svg" mt="48px"/>
                    <HStack justify="space-between">
                         {timesamps.map((timestamp ) => (
                            <Text key={timestamp} fontSize="sm" color="black.80">
                                 {timestamp}
                             </Text>
                                 ))}
                    </HStack>
                </TabPanel>
                <TabPanel>
                    <p>two!</p>
                </TabPanel>
            </TabPanels>
        </Tabs>

    </CustomCard>
  )
}

export default PricingSection
