import Dashbord from "./Pages/Dashbord/Dashbord"
import {createBrowserRouter, RouterProvider } from "react-router-dom";
import Support from "./Pages/Support/Support";
import Transaction from "./Pages/Transaction/Transaction";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Dashbord/>,
  },
  {
    path: "/transaction",
    element: <Transaction />,
  },
  {
    path: "/support",
    element: <Support/>,
  },
]);

function App() {


  return (
    <>
    <RouterProvider router={router} />
    </>
  )
}

export default App
